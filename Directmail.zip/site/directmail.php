<?php
	echo "Direct Mail Component";
?>