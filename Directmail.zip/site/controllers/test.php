<?php
// No direct access to this file
defined('_JEXEC') or die('');
 
 
/**
 * Directmail Component Controller
 */
class DirectMailControllerTest extends JControllerLegacy
{
}
?>
