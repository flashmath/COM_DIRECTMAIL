ALTER TABLE `#__directmail` ADD `checked_out` INTEGER UNSIGNED NOT NULL default '0';
