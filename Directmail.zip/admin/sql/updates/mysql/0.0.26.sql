ALTER TABLE `#__directmail` ADD `ordering` INTEGER NOT NULL default '0';
